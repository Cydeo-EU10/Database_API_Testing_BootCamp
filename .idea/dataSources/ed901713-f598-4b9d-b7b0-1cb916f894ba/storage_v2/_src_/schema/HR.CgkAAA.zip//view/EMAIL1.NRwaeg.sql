create view EMAIL1 as
select initcap(EMAIL) as initemail from EMPLOYEES
/

