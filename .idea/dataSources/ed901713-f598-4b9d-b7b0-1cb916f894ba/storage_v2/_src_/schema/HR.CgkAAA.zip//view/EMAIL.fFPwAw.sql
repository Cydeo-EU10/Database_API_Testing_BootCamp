create view EMAIL as
select FIRST_NAME || '.' || LAST_NAME || '@gmail.com' as fullEmail from EMPLOYEES
/

